var like = 0

function addLike(element){
    like++
    var like_num = document.querySelector("#like_number")
    like_num.innerHTML = like
    
}

// var like2 = 12

function addLike2(element){
    like++
    var like_num = document.querySelector("#like_number2")
    like_num.innerHTML = like
    
}


// var like3 = 9

function addLike3(element){
    like++
    var like_num = document.querySelector("#like_number3")
    like_num.innerHTML = like
    
}