var like = 3

function addLike(){
    like++
    var like_num = document.querySelector("#like_number")
    like_num.innerHTML = like
    
}