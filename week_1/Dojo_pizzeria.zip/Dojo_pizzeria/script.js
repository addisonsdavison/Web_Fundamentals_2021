var p1 = pizzaShop("deepdish", "traditional", "mozzarella", ["pepperoni", "sausage"])

function pizzaShop(crust, sauce, toppings, protein){
    var pizza = {};
    pizza.crust = crust;
    pizza.sauce = sauce;
    pizza.toppings = toppings;
    pizza.protein = protein;
    return pizza;
}
console.log(p1);

    






    
