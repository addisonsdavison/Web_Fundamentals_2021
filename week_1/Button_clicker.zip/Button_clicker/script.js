function turnOff(element) {
    element.innerText = "Logoff";
}

function hide(element) {
    element.remove();
}

function custom() {
    // we can include more code here if we want to
    console.log("Ninja was liked!");
}