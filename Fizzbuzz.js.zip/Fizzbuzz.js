


for(var num = 1; num < 101; num++){
   

    if(num % 3 === 0){
        console.log("Fizz")
    }
    if(num % 5 === 0){
        console.log("Buzz") 
    }
    if(num % 3 === 0 && num % 5 === 5){
        console.log("FizzBuzz")
    }
    else{
        (console.log(num))
    }

}











{
    if(num % 3 === 0){
    console.log("Fizz")
    }
    if(num % 5 === 0){
    console.log("Buzz")
    }
    if(num % 3 === 0 && num % 5 === 5){
    console.log("FizzBuzz")
    }
}



