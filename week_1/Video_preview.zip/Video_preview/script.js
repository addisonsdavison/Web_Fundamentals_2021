console.log("page loaded...");

function over(element) {
    play("myVideo");    
}
    
function out(element) {
    pause("myVideo");    
}

